<?php
/**
 * RDYS - Secure Admin Login
 * * @author Senior Developer
 * @version 2.0.0
 * * صفحه ورود با امنیت بالا و محافظت در برابر حملات متداول.
 */

// بافر خروجی برای جلوگیری از خطای "Headers already sent"
ob_start();
require_once 'functions.php';

// اگر کاربر همین الان لاگین است، هدایت به داشبورد
if (isAdmin()) {
    header("Location: admin.php");
    exit;
}

$error = '';
$usernameValue = '';

// پردازش فرم ورود
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // 1. بررسی Honeypot (ضد ربات ساده)
    // فیلد 'website' در HTML مخفی است. اگر پر شود یعنی ربات است.
    if (!empty($_POST['website'])) {
        die('Access Denied (Bot Detected)');
    }

    $username = cleanInput($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $usernameValue = $username; // نگه داشتن مقدار برای نمایش مجدد

    if (empty($username) || empty($password)) {
        $error = 'لطفا تمام فیلدها را پر کنید.';
    } else {
        try {
            // 2. جستجو در دیتابیس
            $stmt = $pdo->prepare("SELECT id, username, password, role FROM users WHERE username = ? LIMIT 1");
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            // 3. بررسی رمز عبور (Verify Hash)
            if ($user && password_verify($password, $user['password'])) {
                
                // 4. جلوگیری از Session Fixation Attack
                session_regenerate_id(true);
                
                // تنظیم سشن‌های کاربر
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                
                // هدایت به پنل مدیریت
                header("Location: admin.php");
                exit;

            } else {
                // 5. ایجاد تاخیر مصنوعی برای کند کردن حملات Brute Force
                sleep(1); 
                $error = 'نام کاربری یا رمز عبور اشتباه است.';
            }

        } catch (PDOException $e) {
            // در محیط پروداکشن نباید خطای دقیق دیتابیس را نشان داد
            error_log($e->getMessage());
            $error = 'خطای سیستمی رخ داد. لطفا بعدا تلاش کنید.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ورود به مدیریت | RDYS</title>
    <link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet"/>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Vazirmatn', 'sans-serif'] },
                    colors: {
                        bg: "#15202B", card: "#192734", primary: "#1D9BF0", 
                        text: "#F7F9F9", sec: "#8899A6", border: "#38444D", error: "#F91880"
                    }
                }
            }
        }
    </script>
    <style>
        body { background-color: #15202B; color: #F7F9F9; }
        /* استایل خاص برای اتوفیل کروم که رنگ پس‌زمینه را خراب نکند */
        input:-webkit-autofill,
        input:-webkit-autofill:hover, 
        input:-webkit-autofill:focus, 
        input:-webkit-autofill:active{
            -webkit-box-shadow: 0 0 0 30px #15202B inset !important;
            -webkit-text-fill-color: white !important;
            caret-color: white;
        }
    </style>
</head>
<body class="flex items-center justify-center min-h-screen p-4 relative overflow-hidden">

    <!-- Background Shapes -->
    <div class="absolute -top-20 -left-20 w-80 h-80 bg-primary/5 rounded-full blur-[100px] pointer-events-none"></div>
    <div class="absolute -bottom-20 -right-20 w-80 h-80 bg-pink-500/5 rounded-full blur-[100px] pointer-events-none"></div>

    <div class="w-full max-w-sm z-10">
        
        <!-- Header -->
        <div class="text-center mb-8">
            <a href="index.php" class="inline-block mb-4 p-3 bg-card rounded-full border border-border shadow-lg">
                <svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path></svg>
            </a>
            <h1 class="text-2xl font-black tracking-tight">پنل مدیریت</h1>
            <p class="text-sec text-sm mt-2">لطفا برای ادامه وارد شوید</p>
        </div>

        <!-- Login Card -->
        <div class="bg-card border border-border rounded-2xl p-6 md:p-8 shadow-2xl relative">
            
            <?php if ($error): ?>
                <div class="bg-error/10 border border-error/20 text-error px-4 py-3 rounded-xl text-sm font-medium mb-6 flex items-center gap-2 animate-bounce-slight">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    <span><?php echo htmlspecialchars($error); ?></span>
                </div>
            <?php endif; ?>

            <form method="POST" action="" autocomplete="off">
                <!-- Honeypot Field (Hidden) -->
                <div style="display:none; opacity:0; visibility:hidden;">
                    <input type="text" name="website" tabindex="-1" autocomplete="off">
                </div>

                <!-- Username -->
                <div class="mb-5 group">
                    <label class="block text-sec text-xs font-bold mb-2 uppercase tracking-wider group-focus-within:text-primary transition-colors">نام کاربری</label>
                    <div class="relative">
                        <span class="absolute inset-y-0 right-0 flex items-center pr-3 text-sec group-focus-within:text-primary transition-colors">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
                        </span>
                        <input type="text" name="username" value="<?php echo htmlspecialchars($usernameValue); ?>" required autofocus
                               class="w-full bg-bg border border-border text-text rounded-xl py-3 pr-10 pl-4 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all placeholder-sec/30" 
                               placeholder="مثلا: admin">
                    </div>
                </div>

                <!-- Password -->
                <div class="mb-8 group">
                    <label class="block text-sec text-xs font-bold mb-2 uppercase tracking-wider group-focus-within:text-primary transition-colors">رمز عبور</label>
                    <div class="relative">
                        <span class="absolute inset-y-0 right-0 flex items-center pr-3 text-sec group-focus-within:text-primary transition-colors">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path></svg>
                        </span>
                        <input type="password" name="password" required
                               class="w-full bg-bg border border-border text-text rounded-xl py-3 pr-10 pl-4 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all placeholder-sec/30" 
                               placeholder="••••••••">
                    </div>
                </div>

                <!-- Submit Button -->
                <button type="submit" class="w-full bg-primary hover:bg-blue-500 text-white font-bold py-3.5 rounded-xl shadow-lg shadow-blue-500/20 transform transition-all active:scale-95 flex items-center justify-center gap-2">
                    <span>ورود امن</span>
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1"></path></svg>
                </button>
            </form>
        </div>

        <!-- Back Link -->
        <div class="text-center mt-6">
            <a href="index.php" class="text-sec hover:text-text text-sm transition-colors flex items-center justify-center gap-1 group">
                <svg class="w-4 h-4 transform group-hover:-translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
                <span>بازگشت به سایت</span>
            </a>
        </div>

    </div>

</body>
</html>
<?php ob_end_flush(); ?>