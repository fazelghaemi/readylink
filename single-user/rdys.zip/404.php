<?php
/**
 * RDYS - Custom 404 Error Page
 * * @author Senior Developer
 * @version 2.0.0
 * * صفحه‌ای زیبا برای نمایش خطای "لینک یافت نشد".
 */

// تلاش برای لود کردن کانفیگ برای دسترسی به ثابت‌ها (اگر در دسترس باشد)
if (file_exists('config.php')) {
    include_once 'config.php';
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>صفحه مورد نظر یافت نشد | RDYS</title>
    
    <!-- Fonts -->
    <link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet"/>
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Vazirmatn', 'sans-serif'] },
                    colors: {
                        bg: "#15202B", card: "#192734", primary: "#1D9BF0", 
                        text: "#F7F9F9", sec: "#8899A6", border: "#38444D"
                    },
                    animation: {
                        'float': 'float 6s ease-in-out infinite',
                    },
                    keyframes: {
                        float: {
                            '0%, 100%': { transform: 'translateY(0)' },
                            '50%': { transform: 'translateY(-20px)' },
                        }
                    }
                }
            }
        }
    </script>
    <style>
        body { background-color: #15202B; color: #F7F9F9; overflow: hidden; }
        .text-outline {
            -webkit-text-stroke: 2px #38444D;
            color: transparent;
        }
    </style>
</head>
<body class="flex items-center justify-center min-h-screen p-4 relative">

    <!-- Background Elements -->
    <div class="absolute top-1/4 left-1/4 w-64 h-64 bg-primary/10 rounded-full blur-[100px] pointer-events-none animate-pulse"></div>
    <div class="absolute bottom-1/4 right-1/4 w-64 h-64 bg-purple-500/10 rounded-full blur-[100px] pointer-events-none animate-pulse" style="animation-delay: 1s;"></div>

    <div class="text-center z-10 max-w-lg mx-auto">
        
        <!-- Big 404 Text -->
        <div class="relative mb-8 select-none">
            <h1 class="text-[150px] md:text-[200px] font-black leading-none text-outline animate-float opacity-50">
                404
            </h1>
            <div class="absolute inset-0 flex items-center justify-center">
                <span class="text-9xl md:text-[150px] font-black text-primary/20 blur-sm transform translate-y-4">404</span>
            </div>
        </div>

        <!-- Message -->
        <h2 class="text-3xl font-bold mb-4 text-text">لینک پیدا نشد!</h2>
        <p class="text-sec text-lg mb-10 leading-relaxed">
            متاسفانه لینکی که به دنبال آن هستید وجود ندارد، منقضی شده است و یا آدرس آن تغییر کرده است.
        </p>

        <!-- Action Button -->
        <a href="index.php" class="inline-flex items-center gap-2 bg-primary hover:bg-blue-500 text-white font-bold py-4 px-8 rounded-2xl shadow-lg shadow-blue-500/30 transition-all transform hover:scale-105 active:scale-95">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
            <span>بازگشت به صفحه اصلی</span>
        </a>
        
        <div class="mt-12 text-sm text-sec opacity-60">
            RDYS URL Shortener
        </div>

    </div>

</body>
</html>