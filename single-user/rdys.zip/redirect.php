<?php
/**
 * RDYS - Redirection Engine
 * * @author Senior Developer
 * @version 2.0.0
 * * این فایل مسئول هدایت کاربر به لینک اصلی و ثبت آمار بازدید است.
 */

// اتصال به هسته (فقط توابع ضروری برای سرعت بیشتر)
require_once 'functions.php';

// 1. دریافت کد کوتاه از پارامتر URL
// این پارامتر توسط .htaccess ارسال می‌شود
$code = isset($_GET['code']) ? trim($_GET['code']) : '';

// اگر کدی وجود ندارد، به صفحه اصلی برو
if (empty($code)) {
    header("Location: index.php");
    exit;
}

// پاکسازی کد برای امنیت (فقط حروف و اعداد و خط تیره مجاز است)
$code = preg_replace('/[^a-zA-Z0-9-_]/', '', $code);

try {
    // 2. جستجوی لینک در دیتابیس
    // فقط ستون‌های ضروری را انتخاب می‌کنیم (Performance Optimization)
    $stmt = $pdo->prepare("SELECT id, long_url, is_active FROM links WHERE short_code = ? LIMIT 1");
    $stmt->execute([$code]);
    $link = $stmt->fetch();

    if ($link) {
        // 3. بررسی فعال بودن لینک (اگر سیستمی برای غیرفعال‌سازی دارید)
        // در دیتابیس فعلی ما is_active نداریم اما اگر در آینده اضافه شود اینجا چک می‌شود
        // فعلا فرض بر فعال بودن است
        
        // 4. ثبت آمار (Analytics)
        // نکته حرفه‌ای: در سیستم‌های بسیار بزرگ (High Traffic)، این بخش به یک صف (Queue) مثل Redis منتقل می‌شود.
        // اما برای این پروژه، درج مستقیم در MySQL با بهینه‌سازی کافی است.
        
        $ip = getClientIP();
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
        $referrer = $_SERVER['HTTP_REFERER'] ?? ''; // سایتی که کاربر از آن آمده
        
        // تراکنش ثبت آمار و آپدیت تعداد بازدید
        $pdo->beginTransaction();
        
        // الف) درج جزئیات در جدول stats
        $statsStmt = $pdo->prepare("INSERT INTO stats (link_id, ip_address, referrer, user_agent, created_at) VALUES (?, ?, ?, ?, NOW())");
        $statsStmt->execute([$link['id'], $ip, $referrer, $userAgent]);
        
        // ب) افزایش شمارنده بازدید کل در جدول links (برای دسترسی سریع در پنل)
        $updateStmt = $pdo->prepare("UPDATE links SET views = views + 1 WHERE id = ?");
        $updateStmt->execute([$link['id']]);
        
        $pdo->commit();

        // 5. تنظیم هدرهای HTTP و ریدارکت
        // جلوگیری از کش شدن ریدارکت توسط مرورگر (برای اینکه آمار دقیق بماند)
        header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");

        // ریدارکت 301 (دائمی) یا 302 (موقت)؟
        // برای لینک‌های کوتاه سرویس‌دهنده، معمولاً 301 برای SEO بهتر است،
        // اما اگر می‌خواهید همیشه آمار دقیق بگیرید و کنترل کامل داشته باشید، 302 امن‌تر است (چون کش نمی‌شود).
        // اینجا از 301 استفاده می‌کنیم اما با هدرهای no-cache بالا کنترلش می‌کنیم.
        header("HTTP/1.1 301 Moved Permanently");
        header("Location: " . $link['long_url']);
        exit;

    } else {
        // 6. لینک پیدا نشد (404)
        // تنظیم کد وضعیت 404
        http_response_code(404);
        
        // فراخوانی صفحه گرافیکی 404
        // اگر فایل 404.php وجود داشت آن را نشان بده، وگرنه پیام ساده
        if (file_exists('404.php')) {
            require_once '404.php';
        } else {
            // فال‌بک ساده اگر هنوز فایل 404 ساخته نشده
            echo "<h1>404 - Link Not Found</h1>";
            echo "<p>The requested short link does not exist.</p>";
            echo "<a href='index.php'>Go Home</a>";
        }
        exit;
    }

} catch (PDOException $e) {
    // در صورت خطای دیتابیس در هنگام ریدارکت
    error_log("Redirect Error: " . $e->getMessage());
    header("Location: index.php"); // هدایت به صفحه اصلی در صورت خرابی
    exit;
}
?>