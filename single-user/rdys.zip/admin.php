<?php
/**
 * RDYS - Admin Dashboard
 * * @author Senior Developer
 * @version 2.0.0
 * * پنل مدیریت کامل با قابلیت مشاهده آمار، مدیریت لینک‌ها و تنظیمات دامنه‌ها.
 */

require_once 'functions.php';

// 1. بررسی امنیت: آیا کاربر مدیر است؟
if (!isAdmin()) {
    header("Location: login.php");
    exit;
}

// 2. خروج از سیستم
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: login.php");
    exit;
}

// 3. دریافت داده‌های اولیه (Server-Side Data Fetching)
try {
    // آمار کلی
    $totalLinks = $pdo->query("SELECT COUNT(*) FROM links")->fetchColumn();
    $totalViews = $pdo->query("SELECT COUNT(*) FROM stats")->fetchColumn(); // تعداد کل رکوردهای جدول آمار
    
    // لیست 50 لینک اخیر با جوین به جدول دامنه‌ها و محاسبه تعداد بازدیدها
    // نکته پرفورمنس: در مقیاس بالا، شمارش stats باید کش شود یا در جدول links ذخیره شود (که ما ستون views را داریم اما اینجا دقیق محاسبه میکنیم)
    $stmt = $pdo->prepare("
        SELECT 
            l.id, l.long_url, l.short_code, l.created_at, l.views,
            d.domain
        FROM links l
        LEFT JOIN domains d ON l.domain_id = d.id
        ORDER BY l.created_at DESC 
        LIMIT 50
    ");
    $stmt->execute();
    $recentLinks = $stmt->fetchAll();

    // لیست دامنه‌ها
    $domainsList = $pdo->query("SELECT * FROM domains ORDER BY id DESC")->fetchAll();

} catch (PDOException $e) {
    die("Error loading admin data: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>پنل مدیریت | RDYS</title>
    
    <!-- Fonts -->
    <link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet"/>
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Vazirmatn', 'sans-serif'], mono: ['ui-monospace', 'monospace'] },
                    colors: {
                        bg: "#15202B", card: "#192734", primary: "#1D9BF0", 
                        text: "#F7F9F9", sec: "#8899A6", border: "#38444D", 
                        success: "#00BA7C", error: "#F91880"
                    }
                }
            }
        }
    </script>
    
    <!-- Chart.js Library -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        body { background-color: #15202B; color: #F7F9F9; }
        /* استایل اسکرول بار */
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: #15202B; }
        ::-webkit-scrollbar-thumb { background: #38444D; border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: #1D9BF0; }
        
        .nav-item.active { background-color: rgba(29, 155, 240, 0.1); color: #1D9BF0; border-right: 3px solid #1D9BF0; }
        .nav-item { border-right: 3px solid transparent; }
    </style>
</head>
<body class="h-screen flex overflow-hidden selection:bg-primary selection:text-white">

    <!-- Sidebar (Desktop) -->
    <aside class="hidden md:flex flex-col w-64 bg-card border-l border-border h-full flex-shrink-0 z-20 shadow-xl">
        <div class="p-6 flex items-center gap-3 border-b border-border">
            <div class="w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center text-primary">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
            </div>
            <div>
                <h1 class="font-black text-lg tracking-tight">پنل مدیریت</h1>
                <p class="text-xs text-sec">نسخه حرفه‌ای 2.0</p>
            </div>
        </div>

        <nav class="flex-grow p-4 space-y-2 overflow-y-auto">
            <button onclick="switchTab('dashboard')" id="nav-dashboard" class="nav-item active w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sec hover:bg-bg hover:text-text transition-all text-sm font-bold">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"></path></svg>
                داشبورد و لینک‌ها
            </button>
            
            <button onclick="switchTab('domains')" id="nav-domains" class="nav-item w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sec hover:bg-bg hover:text-text transition-all text-sm font-bold">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"></path></svg>
                مدیریت دامنه‌ها
            </button>

            <a href="index.php" target="_blank" class="nav-item w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sec hover:bg-bg hover:text-text transition-all text-sm font-bold">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path></svg>
                مشاهده سایت
            </a>
        </nav>

        <div class="p-4 border-t border-border">
            <div class="flex items-center gap-3 mb-4 px-2">
                <div class="w-8 h-8 rounded-full bg-gradient-to-tr from-primary to-purple-500"></div>
                <div>
                    <p class="text-sm font-bold text-text"><?php echo htmlspecialchars($_SESSION['username'] ?? 'Admin'); ?></p>
                    <p class="text-xs text-sec">مدیر کل</p>
                </div>
            </div>
            <a href="?logout=true" class="flex items-center justify-center gap-2 w-full bg-error/10 hover:bg-error/20 text-error font-bold py-2 rounded-xl transition-colors text-sm">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg>
                خروج امن
            </a>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="flex-grow h-full overflow-y-auto relative w-full">
        
        <!-- Mobile Header -->
        <header class="md:hidden flex items-center justify-between p-4 bg-card border-b border-border sticky top-0 z-30">
            <h1 class="font-black text-xl text-primary">RDYS</h1>
            <div class="flex gap-4">
                <a href="index.php" class="text-sec"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg></a>
                <a href="?logout=true" class="text-error"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg></a>
            </div>
        </header>
        
        <!-- Mobile Tabs -->
        <div class="md:hidden flex border-b border-border bg-bg sticky top-[60px] z-20">
            <button onclick="switchTab('dashboard')" class="flex-1 py-3 text-sm font-bold text-center border-b-2 border-primary text-primary" id="mob-dashboard">داشبورد</button>
            <button onclick="switchTab('domains')" class="flex-1 py-3 text-sm font-bold text-center border-b-2 border-transparent text-sec" id="mob-domains">دامنه‌ها</button>
        </div>

        <div class="p-4 md:p-8 max-w-6xl mx-auto pb-20">
            
            <!-- Tab: Dashboard -->
            <div id="tab-dashboard" class="animate-fade-in">
                
                <!-- Stats Cards -->
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                    <div class="bg-card p-5 rounded-2xl border border-border shadow-sm">
                        <p class="text-sec text-xs font-bold uppercase tracking-wider mb-2">کل لینک‌ها</p>
                        <p class="text-3xl font-black text-text"><?php echo number_format($totalLinks); ?></p>
                    </div>
                    <div class="bg-card p-5 rounded-2xl border border-border shadow-sm">
                        <p class="text-sec text-xs font-bold uppercase tracking-wider mb-2">کل بازدیدها</p>
                        <p class="text-3xl font-black text-primary"><?php echo number_format($totalViews); ?></p>
                    </div>
                </div>

                <!-- Recent Links Table -->
                <div class="bg-card rounded-2xl border border-border overflow-hidden shadow-lg">
                    <div class="p-5 border-b border-border flex justify-between items-center bg-card/50 backdrop-blur-sm sticky top-0 z-10">
                        <h2 class="font-bold text-lg">آخرین لینک‌های ساخته شده</h2>
                        <span class="text-xs text-sec bg-bg px-2 py-1 rounded border border-border">50 مورد اخیر</span>
                    </div>
                    
                    <div class="overflow-x-auto">
                        <table class="w-full text-right text-sm">
                            <thead class="bg-bg text-sec border-b border-border">
                                <tr>
                                    <th class="p-4 font-bold whitespace-nowrap">لینک کوتاه</th>
                                    <th class="p-4 font-bold whitespace-nowrap">مقصد (لینک اصلی)</th>
                                    <th class="p-4 font-bold whitespace-nowrap text-center">کلیک</th>
                                    <th class="p-4 font-bold whitespace-nowrap text-center">تاریخ</th>
                                    <th class="p-4 font-bold whitespace-nowrap text-center">عملیات</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-border">
                                <?php if (count($recentLinks) > 0): ?>
                                    <?php foreach ($recentLinks as $link): ?>
                                    <tr class="hover:bg-bg/50 transition-colors group">
                                        <td class="p-4 whitespace-nowrap ltr text-left">
                                            <a href="<?php echo 'http://' . $link['domain'] . '/' . $link['short_code']; ?>" target="_blank" class="text-primary font-mono hover:underline font-bold">
                                                /<?php echo htmlspecialchars($link['short_code']); ?>
                                            </a>
                                            <div class="text-[10px] text-sec mt-1"><?php echo htmlspecialchars($link['domain']); ?></div>
                                        </td>
                                        <td class="p-4 max-w-xs truncate" title="<?php echo htmlspecialchars($link['long_url']); ?>">
                                            <span class="text-text/80 dir-ltr block truncate"><?php echo htmlspecialchars($link['long_url']); ?></span>
                                        </td>
                                        <td class="p-4 text-center">
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary/10 text-primary">
                                                <?php echo number_format($link['views']); ?>
                                            </span>
                                        </td>
                                        <td class="p-4 text-center text-sec text-xs">
                                            <?php echo timeAgo($link['created_at']); ?>
                                        </td>
                                        <td class="p-4 text-center whitespace-nowrap">
                                            <div class="flex items-center justify-center gap-2 opacity-100 md:opacity-0 group-hover:opacity-100 transition-opacity">
                                                <button onclick="openStatsModal(<?php echo $link['id']; ?>)" class="p-2 text-primary hover:bg-primary/10 rounded-lg transition" title="آمار دقیق">
                                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg>
                                                </button>
                                                <button onclick="deleteLink(<?php echo $link['id']; ?>, this)" class="p-2 text-error hover:bg-error/10 rounded-lg transition" title="حذف">
                                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="5" class="p-8 text-center text-sec">
                                            هنوز هیچ لینکی ساخته نشده است.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Tab: Domains -->
            <div id="tab-domains" class="hidden animate-fade-in">
                <div class="bg-card rounded-2xl border border-border p-6 md:p-8 max-w-3xl mx-auto shadow-lg">
                    <h2 class="text-2xl font-black mb-6 flex items-center gap-2">
                        <svg class="w-7 h-7 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"></path></svg>
                        مدیریت دامنه‌ها
                    </h2>
                    
                    <!-- Add Domain Form -->
                    <form onsubmit="addDomain(event)" class="flex flex-col md:flex-row gap-3 mb-8 bg-bg p-4 rounded-xl border border-border">
                        <input type="text" name="domain" placeholder="مثال: link.mysite.com" required 
                               class="flex-grow bg-card border border-border text-text px-4 py-3 rounded-xl focus:border-primary focus:ring-1 focus:ring-primary outline-none ltr placeholder-sec/50">
                        <button type="submit" class="bg-success hover:bg-green-600 text-white font-bold py-3 px-6 rounded-xl transition shadow-lg shadow-green-500/20 whitespace-nowrap">
                            افزودن دامنه
                        </button>
                    </form>

                    <!-- Domain List -->
                    <div class="space-y-3">
                        <?php foreach ($domainsList as $domain): ?>
                        <div class="flex items-center justify-between p-4 bg-bg rounded-xl border border-border hover:border-sec/30 transition-colors">
                            <div class="flex items-center gap-3">
                                <div class="w-2 h-2 rounded-full <?php echo $domain['is_active'] ? 'bg-success shadow-[0_0_8px_rgba(0,186,124,0.6)]' : 'bg-error'; ?>"></div>
                                <span class="font-mono text-lg font-bold ltr"><?php echo htmlspecialchars($domain['domain']); ?></span>
                            </div>
                            <div class="flex items-center gap-2">
                                <span class="text-xs text-sec hidden md:inline"><?php echo $domain['is_active'] ? 'فعال' : 'غیرفعال'; ?></span>
                                <button onclick="toggleDomain(<?php echo $domain['id']; ?>)" class="p-2 bg-card border border-border rounded-lg hover:bg-primary hover:text-white hover:border-primary transition text-sec" title="تغییر وضعیت">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path></svg>
                                </button>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

        </div>
    </main>

    <!-- Stats Modal (Hidden by default) -->
    <div id="statsModal" class="fixed inset-0 z-50 hidden flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fade-in">
        <div class="bg-card w-full max-w-4xl rounded-3xl border border-border shadow-2xl overflow-hidden relative flex flex-col max-h-[90vh]">
            <div class="p-6 border-b border-border flex justify-between items-center">
                <h3 class="text-xl font-black text-text">آمار تحلیلی</h3>
                <button onclick="closeStatsModal()" class="text-sec hover:text-error transition"><svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg></button>
            </div>
            
            <div class="p-6 overflow-y-auto flex-grow">
                <!-- Chart Canvas -->
                <div class="h-[300px] w-full mb-8 relative">
                    <canvas id="clicksChart"></canvas>
                </div>
                
                <!-- Browser Stats List -->
                <div>
                    <h4 class="font-bold text-sec text-sm uppercase mb-4 border-b border-border pb-2">مرورگرهای برتر</h4>
                    <div id="browserStatsList" class="grid grid-cols-2 md:grid-cols-3 gap-4">
                        <!-- Filled by JS -->
                    </div>
                </div>
            </div>
            
            <!-- Loading Overlay within Modal -->
            <div id="chartLoader" class="absolute inset-0 bg-card/90 flex items-center justify-center z-10 hidden">
                <div class="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
            </div>
        </div>
    </div>

    <!-- JavaScript Logic -->
    <script>
        // Tab Switching Logic
        function switchTab(tabName) {
            // Hide all tabs
            document.getElementById('tab-dashboard').classList.add('hidden');
            document.getElementById('tab-domains').classList.add('hidden');
            
            // Show selected tab
            document.getElementById('tab-' + tabName).classList.remove('hidden');
            
            // Update Sidebar Active State
            document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
            const navItem = document.getElementById('nav-' + tabName);
            if(navItem) navItem.classList.add('active');

            // Update Mobile Tabs Active State
            const mobDash = document.getElementById('mob-dashboard');
            const mobDom = document.getElementById('mob-domains');
            
            if (tabName === 'dashboard') {
                mobDash.classList.add('border-primary', 'text-primary');
                mobDash.classList.remove('border-transparent', 'text-sec');
                mobDom.classList.remove('border-primary', 'text-primary');
                mobDom.classList.add('border-transparent', 'text-sec');
            } else {
                mobDom.classList.add('border-primary', 'text-primary');
                mobDom.classList.remove('border-transparent', 'text-sec');
                mobDash.classList.remove('border-primary', 'text-primary');
                mobDash.classList.add('border-transparent', 'text-sec');
            }
        }

        // Delete Link
        async function deleteLink(id, btn) {
            if (!confirm('آیا مطمئن هستید که می‌خواهید این لینک را حذف کنید؟ این عمل غیرقابل بازگشت است.')) return;
            
            try {
                const fd = new FormData();
                fd.append('action', 'delete');
                fd.append('id', id);
                
                const res = await fetch('api.php', { method: 'POST', body: fd });
                const data = await res.json();
                
                if (data.success) {
                    // Remove row with animation
                    const row = btn.closest('tr');
                    row.style.opacity = '0';
                    setTimeout(() => row.remove(), 300);
                } else {
                    alert('خطا: ' + data.message);
                }
            } catch (e) {
                alert('خطای ارتباط با سرور');
            }
        }

        // Add Domain
        async function addDomain(e) {
            e.preventDefault();
            const form = e.target;
            const fd = new FormData(form);
            fd.append('action', 'add_domain');
            
            try {
                const res = await fetch('api.php', { method: 'POST', body: fd });
                const data = await res.json();
                if (data.success) {
                    location.reload(); // Simple reload to show new domain
                } else {
                    alert(data.message);
                }
            } catch (e) { alert('Error connecting to server'); }
        }

        // Toggle Domain
        async function toggleDomain(id) {
            const fd = new FormData(); fd.append('action', 'toggle_domain'); fd.append('id', id);
            await fetch('api.php', { method: 'POST', body: fd });
            location.reload();
        }

        // Chart & Stats Logic
        let chartInstance = null;

        async function openStatsModal(id) {
            document.getElementById('statsModal').classList.remove('hidden');
            document.getElementById('chartLoader').classList.remove('hidden');
            
            try {
                const fd = new FormData();
                fd.append('action', 'get_stats');
                fd.append('id', id);
                
                const res = await fetch('api.php', { method: 'POST', body: fd });
                const data = await res.json();
                
                if (data.success) {
                    renderChart(data.daily);
                    renderBrowsers(data.browsers);
                } else {
                    alert(data.message);
                    closeStatsModal();
                }
            } catch (e) {
                console.error(e);
                alert('خطا در دریافت آمار');
                closeStatsModal();
            } finally {
                document.getElementById('chartLoader').classList.add('hidden');
            }
        }

        function closeStatsModal() {
            document.getElementById('statsModal').classList.add('hidden');
        }

        function renderChart(dailyData) {
            const ctx = document.getElementById('clicksChart').getContext('2d');
            
            if (chartInstance) chartInstance.destroy();
            
            // Twitter Color Palette for Chart
            const gradient = ctx.createLinearGradient(0, 0, 0, 300);
            gradient.addColorStop(0, 'rgba(29, 155, 240, 0.5)'); // Primary with opacity
            gradient.addColorStop(1, 'rgba(29, 155, 240, 0)');

            chartInstance = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: dailyData.map(d => d.date),
                    datasets: [{
                        label: 'تعداد کلیک',
                        data: dailyData.map(d => d.count),
                        borderColor: '#1D9BF0',
                        backgroundColor: gradient,
                        borderWidth: 3,
                        pointBackgroundColor: '#15202B',
                        pointBorderColor: '#1D9BF0',
                        pointBorderWidth: 2,
                        pointRadius: 4,
                        pointHoverRadius: 6,
                        fill: true,
                        tension: 0.4 // Smooth curves
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            backgroundColor: '#192734',
                            titleColor: '#F7F9F9',
                            bodyColor: '#F7F9F9',
                            borderColor: '#38444D',
                            borderWidth: 1,
                            padding: 10,
                            displayColors: false,
                            titleFont: { family: 'Vazirmatn' },
                            bodyFont: { family: 'Vazirmatn' }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: { color: '#38444D', drawBorder: false },
                            ticks: { color: '#8899A6', font: { family: 'Vazirmatn' } }
                        },
                        x: {
                            grid: { display: false },
                            ticks: { color: '#8899A6', font: { family: 'Vazirmatn' } }
                        }
                    }
                }
            });
        }

        function renderBrowsers(browsers) {
            const container = document.getElementById('browserStatsList');
            container.innerHTML = '';
            
            for (const [name, count] of Object.entries(browsers)) {
                container.innerHTML += `
                    <div class="bg-bg border border-border p-3 rounded-xl flex items-center justify-between">
                        <span class="font-bold text-sm">${name}</span>
                        <span class="bg-primary/20 text-primary text-xs px-2 py-1 rounded-md font-mono">${count}</span>
                    </div>
                `;
            }
            
            if (Object.keys(browsers).length === 0) {
                container.innerHTML = '<p class="text-sec text-sm col-span-3 text-center">داده‌ای موجود نیست</p>';
            }
        }

        // Close modal on click outside
        document.getElementById('statsModal').addEventListener('click', function(e) {
            if (e.target === this) closeStatsModal();
        });
    </script>
</body>
</html>