<?php
/**
 * RDYS - Database Installer
 * * @author Senior Developer
 * @version 2.0.0
 * * این فایل جداول مورد نیاز را می‌سازد و ادمین پیش‌فرض را ایجاد می‌کند.
 * * هشدار: پس از نصب موفق، حتما این فایل را حذف کنید.
 */

require_once 'config.php';

// اگر درخواست POST بود (دکمه نصب زده شد)
$message = '';
$status = ''; // success | error

if (isset($_POST['install'])) {
    try {
        // شروع تراکنش برای تضمین یکپارچگی
        $pdo->beginTransaction();

        // 1. جدول کاربران (Users)
        $pdo->exec("CREATE TABLE IF NOT EXISTS `users` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `username` varchar(50) NOT NULL,
            `password` varchar(255) NOT NULL,
            `role` enum('admin','user') DEFAULT 'user',
            `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `username` (`username`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

        // 2. جدول دامنه‌ها (Domains) - برای پشتیبانی از چند دامنه
        $pdo->exec("CREATE TABLE IF NOT EXISTS `domains` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `domain` varchar(255) NOT NULL,
            `is_active` tinyint(1) DEFAULT 1,
            PRIMARY KEY (`id`),
            UNIQUE KEY `domain` (`domain`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

        // 3. جدول لینک‌ها (Links)
        $pdo->exec("CREATE TABLE IF NOT EXISTS `links` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `user_id` int(11) DEFAULT NULL,
            `domain_id` int(11) DEFAULT 1,
            `long_url` text NOT NULL,
            `short_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
            `views` int(11) DEFAULT 0,
            `is_public` tinyint(1) DEFAULT 1,
            `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `short_code` (`short_code`),
            KEY `user_id` (`user_id`),
            KEY `domain_id` (`domain_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

        // 4. جدول آمار دقیق (Stats)
        $pdo->exec("CREATE TABLE IF NOT EXISTS `stats` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `link_id` int(11) NOT NULL,
            `ip_address` varchar(45) DEFAULT NULL,
            `referrer` varchar(500) DEFAULT NULL,
            `user_agent` varchar(255) DEFAULT NULL,
            `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `link_id` (`link_id`),
            CONSTRAINT `fk_stats_link` FOREIGN KEY (`link_id`) REFERENCES `links` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

        // 5. ایجاد کاربر ادمین پیش‌فرض (اگر وجود ندارد)
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = 'admin'");
        $stmt->execute();
        if ($stmt->fetchColumn() == 0) {
            $adminPass = password_hash('admin', PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username, password, role) VALUES ('admin', ?, 'admin')");
            $stmt->execute([$adminPass]);
        }

        // 6. ایجاد دامنه پیش‌فرض (بر اساس SITE_URL)
        $defaultDomain = parse_url(SITE_URL, PHP_URL_HOST);
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM domains WHERE domain = ?");
        $stmt->execute([$defaultDomain]);
        if ($stmt->fetchColumn() == 0) {
            $stmt = $pdo->prepare("INSERT INTO domains (domain) VALUES (?)");
            $stmt->execute([$defaultDomain]);
        }

        // پایان موفقیت‌آمیز تراکنش
        $pdo->commit();
        $status = 'success';
        $message = 'نصب با موفقیت انجام شد! جداول ایجاد شدند.';

    } catch (PDOException $e) {
        // بازگشت به حالت قبل در صورت خطا
        $pdo->rollBack();
        $status = 'error';
        $message = 'خطا در نصب دیتابیس: ' . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>نصب‌کننده RDYS</title>
    <link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet"/>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>body { font-family: 'Vazirmatn', sans-serif; background-color: #15202B; color: #F7F9F9; }</style>
</head>
<body class="flex items-center justify-center min-h-screen p-4">

    <div class="w-full max-w-md bg-[#192734] border border-[#38444D] rounded-2xl p-8 shadow-2xl text-center">
        
        <div class="mb-6 flex justify-center">
            <div class="w-16 h-16 bg-[#1D9BF0] rounded-full flex items-center justify-center shadow-lg shadow-blue-500/30">
                <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path></svg>
            </div>
        </div>

        <h1 class="text-3xl font-bold mb-2">نصب RDYS</h1>
        <p class="text-[#8899A6] mb-8 text-sm">راه‌اندازی پایگاه داده و تنظیمات اولیه</p>

        <?php if ($status === 'success'): ?>
            <div class="bg-green-500/10 border border-green-500/20 text-green-400 p-4 rounded-xl mb-6 text-sm">
                ✅ <?php echo $message; ?>
            </div>
            
            <div class="bg-[#253341] p-4 rounded-xl text-right text-sm mb-6 border-r-4 border-[#1D9BF0]">
                <p class="text-[#8899A6] mb-1">اطلاعات ورود مدیر:</p>
                <div class="flex justify-between items-center mt-2">
                    <span>نام کاربری: <strong class="text-white">admin</strong></span>
                </div>
                <div class="flex justify-between items-center mt-1">
                    <span>رمز عبور: <strong class="text-white">admin</strong></span>
                </div>
            </div>

            <a href="index.php" class="block w-full bg-[#1D9BF0] hover:bg-blue-500 text-white font-bold py-3 rounded-xl transition shadow-lg shadow-blue-500/20">
                ورود به صفحه اصلی
            </a>
            
            <p class="mt-4 text-xs text-[#F91880]">⚠️ لطفا فایل install.php را پس از اطمینان حذف کنید.</p>

        <?php elseif ($status === 'error'): ?>
            <div class="bg-red-500/10 border border-red-500/20 text-[#F91880] p-4 rounded-xl mb-6 text-sm">
                ❌ <?php echo $message; ?>
            </div>
            <form method="post">
                <button type="submit" name="install" class="block w-full bg-[#1D9BF0] hover:bg-blue-500 text-white font-bold py-3 rounded-xl transition">تلاش مجدد</button>
            </form>
        <?php else: ?>
            <p class="text-sm text-[#8899A6] mb-6 leading-relaxed">
                این اسکریپت جداول <code>users</code>, <code>links</code>, <code>stats</code>, <code>domains</code> را در دیتابیس شما ایجاد می‌کند. آیا آماده هستید؟
            </p>
            <form method="post">
                <button type="submit" name="install" class="block w-full bg-[#1D9BF0] hover:bg-blue-500 text-white font-bold py-3 rounded-xl transition shadow-lg shadow-blue-500/20 transform active:scale-95">
                    شروع نصب اتوماتیک
                </button>
            </form>
        <?php endif; ?>

    </div>

</body>
</html>